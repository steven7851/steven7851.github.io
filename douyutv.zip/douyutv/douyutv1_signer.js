function signer(roomId, time, did) {
    const fs = require('fs')
    const util = require('util')
    const path = require('path')
    const readFile = util.promisify(fs.readFile)
    const FlashEmu = require('flash-emu')
    FlashEmu.BUILTIN = path.dirname(__filename) + '/flash-emu/lib/builtin.abc'
    FlashEmu.PLAYERGLOBAL = path.dirname(__filename) + '/flash-emu/lib/playerglobal.abc'
    FlashEmu.setGlobalFlags({
        enableDebug: false,
        enableLog: false,
        enableWarn: false,
        enableError: false
    })
    const emu = new FlashEmu({
        async readFile(filename) {
            const buf = await readFile(filename)
            return new Uint8Array(buf).buffer
        }
    })
    const vm = emu.getVM()
    emu.runSWF(path.dirname(__filename) + '/douyutv1.swf', false).then(() => {
        const vm = emu.getVM()
        const CModule = vm.getProxy(emu.getProperty('sample.mp', 'CModule'))
        const xx = vm.getProxy(emu.getPublicClass('mp'))
        CModule.callProperty('startAsync')
        let StreamSignDataPtr = CModule.callProperty('malloc', 4)
        let outptr1 = CModule.callProperty('malloc', 4)
        let datalen = xx.callProperty('sub_2', parseInt(roomId), parseInt(time), did.toString(), outptr1, StreamSignDataPtr)
        let pSign = CModule.callProperty('read32', StreamSignDataPtr)
        let sign = CModule.callProperty('readString', pSign, datalen)
        let pOut = CModule.callProperty('read32', outptr1)
        let out = CModule.callProperty('readString', pOut, 4)
        xx.callProperty('sub_3', StreamSignDataPtr)
        CModule.callProperty('free', StreamSignDataPtr)
        xx.callProperty('sub_3', outptr1)
        CModule.callProperty('free', outptr1)
        console.log('sign:', sign, 'cptl:', out)
    }).catch(e => console.error(e))
}
const rid = process.argv[2]
const tt = process.argv[3]
const did = process.argv[4]
signer(rid, tt, did)
