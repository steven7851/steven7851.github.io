function signer(roomId, time, did) {
    const fs = require('fs')
    const util = require('util')
    const path = require('path')
    const readFile = util.promisify(fs.readFile)
    const FlashEmu = require('flash-emu')
    FlashEmu.BUILTIN = path.dirname(__filename) + '/flash-emu/lib/builtin.abc'
    FlashEmu.PLAYERGLOBAL = path.dirname(__filename) + '/flash-emu/lib/playerglobal.abc'
    FlashEmu.setGlobalFlags({
        enableDebug: false,
        enableLog: false,
        enableWarn: false,
        enableError: false
    })
    const emu = new FlashEmu({
        async readFile(filename) {
            const buf = await readFile(filename)
            return new Uint8Array(buf).buffer
        }
    })
    const vm = emu.getVM()
    emu.runSWF(path.dirname(__filename) + '/douyutv_v.swf', false).then(() => {
        const vm = emu.getVM()
        const CModule = vm.getProxy(emu.getProperty('sample.zz', 'CModule'))
        const xx = vm.getProxy(emu.getPublicClass('zz'))
        CModule.callProperty('startAsync')
        let StreamSignDataPtr = CModule.callProperty('malloc', 4)
        let datalen = xx.callProperty('sub_1', parseInt('1'), roomId.toString(), did.toString(), parseInt(time), StreamSignDataPtr)
        let pSign = CModule.callProperty('read32', StreamSignDataPtr)
        let sign = CModule.callProperty('readString', pSign, datalen)
        xx.callProperty('sub_2', StreamSignDataPtr)
        CModule.callProperty('free', StreamSignDataPtr)
        console.log('sign:', sign, 'cptl: 0000')
    }).catch(e => console.error(e))
}
const vid = process.argv[2]
const tt = process.argv[3]
const did = process.argv[4]
signer(vid, tt, did)
